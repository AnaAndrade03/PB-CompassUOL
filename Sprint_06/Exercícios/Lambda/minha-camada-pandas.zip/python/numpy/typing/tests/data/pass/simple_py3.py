import numpy as np

array = np.array([1, 2])

# The @ operator is not in python 2
array @ array
